import mongoose from "mongoose";

const CategoryNews = mongoose.Schema({
  category: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Category",
    required: true
  }
}, { timestamps: true });

export default mongoose.model("CategoryNews", CategoryNews);
