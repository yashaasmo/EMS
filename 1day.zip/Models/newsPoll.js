// Models/Poll.js
import mongoose from "mongoose";

const optionSchema = new mongoose.Schema({
  text: {
    type: String,
    required: true,
    trim: true,
  },
  votes: {
    type: Number,
    default: 0,
  }
});

const pollSchema = new mongoose.Schema(
  {
    question: {
      type: String,
      required: true,
      trim: true,
    },
    options: [optionSchema], // multiple options
    newsId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "News", // poll is always linked to a news
      required: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User", // reporter/admin who created the poll
      required: true,
    },
    voters: [
      {
        user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        option: { type: mongoose.Schema.Types.ObjectId }, // which option they voted
      }
    ],
    status: {
      type: String,
      enum: ["active", "closed"],
      default: "active",
    },
  },
  { timestamps: true }
);

export default mongoose.model("newsPoll", pollSchema);
